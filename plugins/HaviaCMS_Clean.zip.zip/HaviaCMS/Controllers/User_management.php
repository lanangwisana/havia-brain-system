<?php

namespace HaviaCMS\Controllers;

use App\Controllers\Security_Controller;

class User_management extends Security_Controller {

    function __construct() {
        parent::__construct();
        $this->access_only_admin();
    }

    function index() {
        return $this->template->rander("HaviaCMS\Views\user_management\index");
    }

    function modal_form() {
        $this->validate_submitted_data(array(
            "id" => "numeric"
        ));

        $view_data['model_info'] = $this->Users_model->get_one($this->request->getPost('id'));
        return $this->template->view("HaviaCMS\Views\user_management\modal_form", $view_data);
    }

    function list_data() {
        $list_data = $this->Users_model->get_details(array("user_type" => "staff"))->getResult();
        $result = array();
        foreach ($list_data as $data) {
            $result[] = $this->_make_row($data);
        }
        echo json_encode(array("data" => $result));
    }

    private function _make_row($data) {
        $image_url = get_avatar($data->image);
        $user_avatar = "<span class='avatar avatar-xs'><img src='$image_url' alt='...'></span>";

        return array(
            $user_avatar,
            $data->first_name . " " . $data->last_name,
            $data->email,
            $data->job_title,
            modal_anchor(get_uri("user_management/modal_form"), "<i data-feather='edit' class='icon-16'></i>", array("class" => "edit", "title" => app_lang('edit_staff'), "data-post-id" => $data->id))
        );
    }
}
